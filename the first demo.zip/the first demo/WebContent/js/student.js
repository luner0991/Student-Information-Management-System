// 查找
$.ajax({
    url: "SearchStudent", // 请求路径
    type: "get", // 请求方式 get查找     post 添加，删除，修改  
    success: function(value) {
        var arr = value.data;
        for (var i = 0; i < arr.length; i++) {
            $("tbody").append("<tr>" +
                "<td>" + arr[i].id + "</td>" +
                "<td>" + arr[i].name + "</td>" +
                "<td>" + arr[i].age + "</td>" +
                "<td>" + arr[i].sex + "</td>" +
                "<td>" +
                "<input type='button' value='修改' class='u_update' index='" + arr[i].id + "'>" +
                "<input type='button' value='删除' class='delete' index='" + arr[i].id + "'>" +
                "</td>" +
                "</tr>");
        }
    }, // 请求成功的回调函数
    error: function() {
        alert("请求失败啦");
    } // 请求失败的回调函数
});

// 删除
$("tbody").on("click", ".delete", function() {
    var id = $(this).attr("index");
    $.ajax({
        url: "DeleteStudent", // 请求路径
        type: "post", // 请求方式 get post
        data: {
            deleteId: id
        }, // 参数域
        success: function(value) {
            alert(value);
            // 页面刷新
            location.reload();
        }, // 请求成功的回调函数
        error: function() {
            alert("请求失败啦");
        } // 请求失败的回调函数
    });
});

// 添加模块显示
$(".addBtn").on("click", function() {
    $(".addModel").css("display", "block");
});

// 添加模块隐藏
$(".back").on("click", function() {
    $(".addModel").css("display", "none");
});

// 添加
$(".add").on("click", function() {
    var name = $(".name").val().trim();
    var sex = $(".sex").val().trim();
    var age = $(".age").val().trim();
    $.ajax({
        url: "AddStudent", // 请求路径
        type: "post", // 请求方式 get post
        data: {
            addName: name,
            addSex: sex,
            addAge: age,
        }, // 参数域
        success: function(value) {
            alert(value);
            // 页面刷新
            location.reload();
        }, // 请求成功的回调函数
        error: function() {
            alert("请求失败啦");
        } // 请求失败的回调函数
    });
});

// 回显
$("tbody").on("click", ".u_update", function() {
    $(".updateModel").css("display", "block");
    // 获取id
    var id = $(this).attr("index");

    $.ajax({
        url: "SearchById",
        type: "get",
        data: {
            id: id,
        },
        success: function(value) {
            var obj = value.data[0];
            $(".u_update").attr("index", obj.id);
            $(".u_name").val(obj.name);
            $(".u_sex").val(obj.sex);
            $(".u_age").val(obj.age);
        }, // 请求成功的回调函数
        error: function() {
            alert("请求失败啦");
        } // 请求失败的回调函数
    });
});

// 修改模块隐藏
$(".u_back").on("click", function() {
    $(".updateModel").css("display", "none");
});

// 修改
$(".u_update").on("click", function() {
    var id = $(".u_update").attr("index");
    var name = $(".u_name").val();
    var age = $(".u_age").val();
    var sex = $(".u_sex").val();
    $.ajax({
        url: "UpdateServlet",
        type: "post",
        data: {
            id: id,
            name: name,
            age: age,
            sex: sex,
        },
        success: function(value) {
            alert(value);
            location.reload();
        }, // 请求成功的回调函数
        error: function() {
            alert("请求失败啦");
        } // 请求失败的回调函数
    });
});