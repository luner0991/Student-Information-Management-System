package com.lxy.util;

import java.sql.DriverManager;
import java.sql.ResultSet;

import org.omg.CORBA.PUBLIC_MEMBER;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Driver;
import com.mysql.jdbc.Statement;

public class Test {
	public static void main(String[] args) {
		String sql = "update student set name=\"小66\",age=19,sex=\"男\" where id =4\r\n" + 
				"";
		add(sql);
		
	}
	//查找
	public static void search(String sql) {
		//和navicat的查询sql操作差不多
		
			//报错原因：驱动包可能找不到，点击红线可以try/catch或者抛出，后续代码在try中写
		try {
			//1、:加载驱动，没有驱动无法调用数据库	
			Class.forName("com.mysql.jdbc.Driver");//8. 版本的是com.mysql.cj.jdbc.Driver
			
			//2、：填写用户信息和url
			String url="jdbc:mysql://localhost:3306/thefirst";
			String username = "root";
			String password = "2020";
			
			//3、：驱动管理类调用方法进行连接，找到连接对象
				//报错：需要强制类型转换   子类 对象名 =（子类）父类
			Connection con = (Connection) DriverManager.getConnection(url, username, password);
			
			//4、：创建执行sql的对象,同样需要强制类型转换
			Statement statement = (Statement) con.createStatement();
			
			//5、：执行sql语句
				//executeQuery用于查找，获得返回结果
			ResultSet resultSet = statement.executeQuery(sql);
			//6、resultSet处理数据 resultSet.next()指向下一行【默认指向不是数据的第一行，所以要next】
			while (resultSet.next()) {
			    int id = resultSet.getInt("id");
			    String name = resultSet.getString("name");
			    String sex = resultSet.getString("sex");
			    int age = resultSet.getInt("age");
			    System.out.println("id: " + id + ", name: " + name + ", sex: " + sex + ", age: " + age);
			}
			//7、释放资源:先建立的后释放
			if(resultSet!=null) {
				resultSet.close();
			}
			if(statement!=null) {
				statement.close();
			}
			if(con!=null) {
				con.close();
			}
		} catch (Exception e) {  //ClassNotFound删掉，可以捕获所有出现的异常
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
				
	}
	
	//添加
		public static void add(String sql) {
			try {
				//1、:加载驱动，没有驱动无法调用数据库	
				Class.forName("com.mysql.jdbc.Driver");//8. 版本的是com.mysql.cj.jdbc.Driver
					
				//2、：填写用户信息和url
				String url="jdbc:mysql://localhost:3306/thefirst";
				String username = "root";
				String password = "2020";
				
				//3、：驱动管理类调用方法进行连接，找到连接对象
					//报错：需要强制类型转换   子类 对象名 =（子类）父类
				Connection con = (Connection) DriverManager.getConnection(url, username, password);
					
				//4、：创建执行sql的对象,同样需要强制类型转换
				Statement statement = (Statement) con.createStatement();
				
				//5、：执行sql语句
						//executeupdata用于添加，获得返回结果
				int num = statement.executeUpdate(sql);
					
				//7、释放资源:先建立的后释放
					
				if(statement!=null) {
					statement.close();
				}
				if(con!=null) {
					con.close();
				}
			} catch (Exception e) {  //ClassNotFound删掉，可以捕获所有出现的异常
				// TODO Auto-generated catch block
					e.printStackTrace();
				} 
			}
		
		
		//修改删除 和添加是一样的
}

	
