package com.lxy.db;

public class Test {
	
	public static void main(String[] args){
//		String sql="select * from student";
//		String[] colums ={"id","name","age","sex"};
//		String reString=MysqlUtil.getJsonBySql(sql,colums);
//		System.out.println(reString);
		
		String sql ="insert into student(name,age,sex) values(\"丽丽\",20,\"女\")";
		MysqlUtil.add(sql);
	}

}
