package com.lxy.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lxy.db.MysqlUtil;

/**
 * Servlet implementation class AddStudent
 */
@WebServlet("/AddStudent")
public class AddStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddStudent() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		//接收参数
		String name = request.getParameter("addName");
		String sex = request.getParameter("addSex");
		String age = request.getParameter("addAge");
		//添加
		String sql = "insert into student(name,age,sex) values(\""+name+"\","+age+",\""+sex+"\")";
		int num = MysqlUtil.add(sql);
		
		String res = "添加失败";
		if(num>0) {
			res="添加成功";
		}
		//设置数据编码
		response.setCharacterEncoding("utf-8");
		request.setCharacterEncoding("utf-8");
		//数据返回		
		response.getWriter().write(res);
	}

}
