package com.lxy.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Firstdemo
 */
@WebServlet("/Firstdemo")
public class Firstdemo extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Firstdemo() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("get请求");
		// 获取信息
		String acc = request.getParameter("account");
		String pass = request.getParameter("password");
		String res = "";
		if (acc.equals("admin") && pass.equals("123456")) {
			res = "{ \"name\":\"runoob\",\"alexa\":10000,\"site\":null}";
		} else {
			res = "登陆失败";

		}
		// 设置数据编码
		response.setCharacterEncoding("utf-8");
		request.setCharacterEncoding("utf-8");
		// 设置后端给前端返回的为json格式的数据
		response.setContentType("text/json;charset=utf-8");
		// 给前端响应数据
		response.getWriter().write(res);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

}
